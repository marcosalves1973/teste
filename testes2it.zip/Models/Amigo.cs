﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LojaSistema2.Models
{
    public class Amigo
    {
        [Key]
        public int AmigoID { get; set; }
        [Display(Name = "Nome")]
        [Required(ErrorMessage = "Você precisa entrar com o {0}")]
        public string Nome { get; set; }
        public virtual ICollection<Emprestar> EmprestarAmigo { get; set; }

        [Display(Name = "Sobrenome")]
        public string Sobrenome { get; set; }

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = false)]
        [Display(Name = "Data de nascimento")]
        public DateTime Nascimento { get; set; }
        public string Email { get; set; }




    }
}