﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace LojaSistema2.Models
{
    public class LojaSistema2Context : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public LojaSistema2Context() : base("name=LojaSistema2Context")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
        }
        public System.Data.Entity.DbSet<LojaSistema2.Models.Produto> Produtoes { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.Funcionario> Funcionarios { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.TipoDocumento> TipoDocumentoes { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.Fornecedor> Fornecedors { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.FornecedorProduto> FornecedorProdutoes { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.Amigo> Amigoes { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.Jogo> Jogoes { get; set; }

        public System.Data.Entity.DbSet<LojaSistema2.Models.Emprestar> Emprestars { get; set; }
    }
}
