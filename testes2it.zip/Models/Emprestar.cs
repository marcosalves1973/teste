﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LojaSistema2.Models
{
    public class Emprestar
    {
        [Key]
        public int EmprestimoId { get; set; }
        public DateTime DataEmprestimo { get; set; }
        public int AmigoId { get; set; }
        public virtual Amigo Amigo { get; set; }
        public int JogoId { get; set; }
        public virtual Jogo Jogo { get; set; }
    }
}