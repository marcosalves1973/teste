﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LojaSistema2.Models
{
    public class Jogo
    {
        [Key]
        public int JogoId { get; set; }
        public string JogoNome { get; set; }
        public virtual ICollection<Emprestar> EmprestarJogo { get; set; }

    }
}