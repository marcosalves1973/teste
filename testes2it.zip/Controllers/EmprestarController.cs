﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LojaSistema2.Models;

namespace LojaSistema2.Controllers
{
    public class EmprestarController : Controller
    {
        private LojaSistema2Context db = new LojaSistema2Context();

        // GET: Emprestar
        public ActionResult Index()
        {
            var emprestars = db.Emprestars.Include(e => e.Amigo).Include(e => e.Jogo);
            return View(emprestars.ToList());
        }

        // GET: Emprestar/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Emprestar emprestar = db.Emprestars.Find(id);
            if (emprestar == null)
            {
                return HttpNotFound();
            }
            return View(emprestar);
        }

        // GET: Emprestar/Create
        public ActionResult Create()
        {
            ViewBag.AmigoId = new SelectList(db.Amigoes, "AmigoID", "Nome");
            ViewBag.JogoId = new SelectList(db.Jogoes, "JogoId", "JogoNome");
            return View();
        }

        // POST: Emprestar/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmprestimoId,DataEmprestimo,AmigoId,JogoId")] Emprestar emprestar)
        {
            if (ModelState.IsValid)
            {
                db.Emprestars.Add(emprestar);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.AmigoId = new SelectList(db.Amigoes, "AmigoID", "Nome", emprestar.AmigoId);
            ViewBag.JogoId = new SelectList(db.Jogoes, "JogoId", "JogoNome", emprestar.JogoId);
            return View(emprestar);
        }

        // GET: Emprestar/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Emprestar emprestar = db.Emprestars.Find(id);
            if (emprestar == null)
            {
                return HttpNotFound();
            }
            ViewBag.AmigoId = new SelectList(db.Amigoes, "AmigoID", "Nome", emprestar.AmigoId);
            ViewBag.JogoId = new SelectList(db.Jogoes, "JogoId", "JogoNome", emprestar.JogoId);
            return View(emprestar);
        }

        // POST: Emprestar/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmprestimoId,DataEmprestimo,AmigoId,JogoId")] Emprestar emprestar)
        {
            if (ModelState.IsValid)
            {
                db.Entry(emprestar).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AmigoId = new SelectList(db.Amigoes, "AmigoID", "Nome", emprestar.AmigoId);
            ViewBag.JogoId = new SelectList(db.Jogoes, "JogoId", "JogoNome", emprestar.JogoId);
            return View(emprestar);
        }

        // GET: Emprestar/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Emprestar emprestar = db.Emprestars.Find(id);
            if (emprestar == null)
            {
                return HttpNotFound();
            }
            return View(emprestar);
        }

        // POST: Emprestar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Emprestar emprestar = db.Emprestars.Find(id);
            db.Emprestars.Remove(emprestar);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
