﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LojaSistema2.Models;

namespace LojaSistema2.Controllers
{
    public class FornecedorProdutoController : Controller
    {
        private LojaSistema2Context db = new LojaSistema2Context();

        // GET: FornecedorProduto
        public ActionResult Index()
        {
            var fornecedorProdutoes = db.FornecedorProdutoes.Include(f => f.Fornecedor).Include(f => f.Produto);
            return View(fornecedorProdutoes.ToList());
        }

        // GET: FornecedorProduto/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FornecedorProduto fornecedorProduto = db.FornecedorProdutoes.Find(id);
            if (fornecedorProduto == null)
            {
                return HttpNotFound();
            }
            return View(fornecedorProduto);
        }

        // GET: FornecedorProduto/Create
        public ActionResult Create()
        {
            ViewBag.FornecedorId = new SelectList(db.Fornecedors, "FornecedorId", "Nome");
            ViewBag.ProdutoId = new SelectList(db.Produtoes, "ID", "Descricao");
            return View();
        }

        // POST: FornecedorProduto/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FornecedorProdutoId,FornecedorId,ProdutoId")] FornecedorProduto fornecedorProduto)
        {
            if (ModelState.IsValid)
            {
                db.FornecedorProdutoes.Add(fornecedorProduto);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.FornecedorId = new SelectList(db.Fornecedors, "FornecedorId", "Nome", fornecedorProduto.FornecedorId);
            ViewBag.ProdutoId = new SelectList(db.Produtoes, "ID", "Descricao", fornecedorProduto.ProdutoId);
            return View(fornecedorProduto);
        }

        // GET: FornecedorProduto/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FornecedorProduto fornecedorProduto = db.FornecedorProdutoes.Find(id);
            if (fornecedorProduto == null)
            {
                return HttpNotFound();
            }
            ViewBag.FornecedorId = new SelectList(db.Fornecedors, "FornecedorId", "Nome", fornecedorProduto.FornecedorId);
            ViewBag.ProdutoId = new SelectList(db.Produtoes, "ID", "Descricao", fornecedorProduto.ProdutoId);
            return View(fornecedorProduto);
        }

        // POST: FornecedorProduto/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FornecedorProdutoId,FornecedorId,ProdutoId")] FornecedorProduto fornecedorProduto)
        {
            if (ModelState.IsValid)
            {
                db.Entry(fornecedorProduto).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.FornecedorId = new SelectList(db.Fornecedors, "FornecedorId", "Nome", fornecedorProduto.FornecedorId);
            ViewBag.ProdutoId = new SelectList(db.Produtoes, "ID", "Descricao", fornecedorProduto.ProdutoId);
            return View(fornecedorProduto);
        }

        // GET: FornecedorProduto/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            FornecedorProduto fornecedorProduto = db.FornecedorProdutoes.Find(id);
            if (fornecedorProduto == null)
            {
                return HttpNotFound();
            }
            return View(fornecedorProduto);
        }

        // POST: FornecedorProduto/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            FornecedorProduto fornecedorProduto = db.FornecedorProdutoes.Find(id);
            db.FornecedorProdutoes.Remove(fornecedorProduto);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
